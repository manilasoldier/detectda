# __init__.py
from dtda.detectda import *
